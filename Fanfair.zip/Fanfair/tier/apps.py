from django.apps import AppConfig


class TierConfig(AppConfig):
    name = 'tier'

from django.contrib import admin
from tier.models import Tier, Subscription
# Register your models here.

admin.site.register(Tier)
admin.site.register(Subscription)


## Getting Started

-Install the prerequisites
-Run the server

username:
admin
password:
admin1234

### Prerequisites

You can install the Prerequisites by running the command: 

```
pip install -r requirements.txt

AFTER INSTALLING THE REQUIREMENTS RUN THE FOLLOWING COMMAND

python manage.py runserver

AFTER THAT THE SERVER WILL START

PRESS (ctrl + rt click) on server link to open it on web browser

```

```
asgiref==3.3.1
Django==3.1.5
Pillow==8.1.0
pytz==2020.5
sqlparse==0.3.1
```




